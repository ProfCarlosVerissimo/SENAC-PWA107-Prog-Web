import React, { useState } from 'react';
import ContadorNumeros from './components/ContadorNumeros';
function App() {
  return (
    <div className="App">
      <h1>Aula #6 - useEffect</h1>
      <ContadorNumeros/>
    </div>
  );
}

export default App;
