/**-------------------------------------------------*
 *       SENAC - TADS - Programação Web             *                
 *      Trabalhando com useState (Hook)             *
 *--------------------------------------------------*/
 
import React, { useState } from 'react';
function ContadorNumeros() {
 /* Declara uma nova variável de state, que chamaremos de "count"
  * O único argumento para useState é o state inicial. 
  * Em nosso exemplo é 0 porque nosso contador começa do zero.
 */ 
 const [count, setCount] = useState(0);

 return (
   <div>
     <p>Você clicou {count} vezes</p>
     <button onClick={() => setCount(count + 1)}>
       Soma Valor
     </button>
   </div>
 );}
export default ContadorNumeros;