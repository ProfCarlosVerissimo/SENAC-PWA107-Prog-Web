 

function Contato(){
    return(
        <div>
            <h1>Página de Contato</h1>
            <span>Email: nossaEmpresa@nossaEmpresa.com</span>
            <br/>
            <span>WhatsApp: (11)99666-6666</span><br/>
             
        </div>
    )
}
export default Contato;