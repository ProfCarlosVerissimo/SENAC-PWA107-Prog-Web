

function Home(){
    return(
        <div>
            <h1>Bem vinda a Home</h1>
            <span>Esta é a Home de nossa empresa</span>
            <br/>
            
        </div>
    )
}
export default Home;