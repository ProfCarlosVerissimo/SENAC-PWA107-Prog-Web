import {Link} from 'react-router-dom';
function Sobre(){
    return(
        <div>
            <h1>Bem vinda a Página Sobre</h1>
            <span>Sobre nossa empresa</span>
            <br/>
            <Link to="/">Home</Link><br/>
            <Link to="/contato">Contato</Link>
        </div>
    )
}
export default Sobre;