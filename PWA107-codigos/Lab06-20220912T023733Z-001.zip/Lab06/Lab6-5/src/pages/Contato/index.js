import {Link} from 'react-router-dom';

function Contato(){
    return(
        <div>
            <h1>Página de Contato</h1>
            <span>Email: nossaEmpresa@nossaEmpresa.com</span>
            <br/>
            <span>WhatsApp: (11)99666-6666</span><br/>
            <Link to="/">Home</Link><br/>
            <Link to="/sobre">Sobre</Link>
        </div>
    )
}
export default Contato;