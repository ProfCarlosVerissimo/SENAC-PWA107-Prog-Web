/**-------------------------------------------------*
 *       SENAC - TADS - Programação Web             *                
 *      Trabalhando com useState (Hook)             *
 *--------------------------------------------------*/
  import React  from 'react';
import ReactDOM from 'react-dom/client';
import './index.css'; 
import App from './App';
 // <React.StrictMode>
 //</React.StrictMode>
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
    <App />
  
);
 